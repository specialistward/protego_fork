User-agent: *
Allow: /
Disallow: 
Sitemap: https://brew.sh/sitemap.xml
