User-agent: InwegroBot
Disallow: /

User-Agent: *
Disallow: