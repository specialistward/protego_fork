User-agent: *
Disallow: /static
Disallow: /admin
Disallow: /Admin
Disallow: /RPC
Disallow: /public

User-agent: MJ12bot
Disallow: /

User-agent: SemrushBot
Disallow: /

User-agent: SemanticScholarBot
Disallow: /