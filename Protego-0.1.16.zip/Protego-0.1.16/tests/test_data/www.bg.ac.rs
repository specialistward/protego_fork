User-agent: *
Disallow: /cgi-bin/
Disallow: /test/
Sitemap: http://www.bg.ac.rs/sitemap.xml
