User-agent: *
Disallow: /noindex/

User-agent: *
Disallow: /hnypt/

User-Agent: WebarooBot
Disallow: /

User-Agent: Twiceler
Disallow: /

User-agent: dotbot
Disallow: /

User-agent: Linguee
Disallow: /

User-agent: BUbiNG
Disallow: /

User-agent: Barkrowler
Disallow: /