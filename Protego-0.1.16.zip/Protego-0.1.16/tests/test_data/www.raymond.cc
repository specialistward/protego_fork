User-agent: *
Disallow: /blog/wp-admin/
Sitemap: https://www.raymond.cc/blog/sitemap_index.xml